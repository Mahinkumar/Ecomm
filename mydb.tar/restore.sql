--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.3 (Debian 16.3-1.pgdg120+1)
-- Dumped by pg_dump version 16.3 (Debian 16.3-1.pgdg120+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE local;
--
-- Name: local; Type: DATABASE; Schema: -; Owner: root
--

CREATE DATABASE local WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE local OWNER TO root;

\connect local

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: drizzle; Type: SCHEMA; Schema: -; Owner: root
--

CREATE SCHEMA drizzle;


ALTER SCHEMA drizzle OWNER TO root;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: __drizzle_migrations; Type: TABLE; Schema: drizzle; Owner: root
--

CREATE TABLE drizzle.__drizzle_migrations (
    id integer NOT NULL,
    hash text NOT NULL,
    created_at bigint
);


ALTER TABLE drizzle.__drizzle_migrations OWNER TO root;

--
-- Name: __drizzle_migrations_id_seq; Type: SEQUENCE; Schema: drizzle; Owner: root
--

CREATE SEQUENCE drizzle.__drizzle_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE drizzle.__drizzle_migrations_id_seq OWNER TO root;

--
-- Name: __drizzle_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: drizzle; Owner: root
--

ALTER SEQUENCE drizzle.__drizzle_migrations_id_seq OWNED BY drizzle.__drizzle_migrations.id;


--
-- Name: carts; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.carts (
    cart_sno integer NOT NULL,
    cart_id integer,
    user_id integer,
    product_id integer,
    quantity integer
);


ALTER TABLE public.carts OWNER TO root;

--
-- Name: products; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.products (
    product_id integer NOT NULL,
    name text NOT NULL,
    seller_id integer,
    price integer,
    stock integer,
    section character varying,
    product_image character varying,
    product_description text,
    sales_count integer,
    sales_code integer,
    url character varying
);


ALTER TABLE public.products OWNER TO root;

--
-- Name: sales; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.sales (
    user_id integer,
    product_id integer,
    sell_price integer,
    total_sale_amount integer,
    quantity_sold integer,
    sale_time timestamp without time zone,
    transaction_id integer
);


ALTER TABLE public.sales OWNER TO root;

--
-- Name: transactions; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.transactions (
    transaction_id integer NOT NULL,
    purchase_price integer NOT NULL,
    payment_method character varying,
    sale_time timestamp without time zone,
    user_id integer
);


ALTER TABLE public.transactions OWNER TO root;

--
-- Name: user; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public."user" (
    user_id integer NOT NULL,
    name text NOT NULL,
    is_seller boolean NOT NULL,
    is_admin boolean NOT NULL,
    phone_number integer NOT NULL,
    address character varying NOT NULL,
    cart_id integer,
    email_address character varying NOT NULL,
    password_hash character varying
);


ALTER TABLE public."user" OWNER TO root;

--
-- Name: __drizzle_migrations id; Type: DEFAULT; Schema: drizzle; Owner: root
--

ALTER TABLE ONLY drizzle.__drizzle_migrations ALTER COLUMN id SET DEFAULT nextval('drizzle.__drizzle_migrations_id_seq'::regclass);


--
-- Data for Name: __drizzle_migrations; Type: TABLE DATA; Schema: drizzle; Owner: root
--

COPY drizzle.__drizzle_migrations (id, hash, created_at) FROM stdin;
\.
COPY drizzle.__drizzle_migrations (id, hash, created_at) FROM '$$PATH$$/3393.dat';

--
-- Data for Name: carts; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.carts (cart_sno, cart_id, user_id, product_id, quantity) FROM stdin;
\.
COPY public.carts (cart_sno, cart_id, user_id, product_id, quantity) FROM '$$PATH$$/3387.dat';

--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.products (product_id, name, seller_id, price, stock, section, product_image, product_description, sales_count, sales_code, url) FROM stdin;
\.
COPY public.products (product_id, name, seller_id, price, stock, section, product_image, product_description, sales_count, sales_code, url) FROM '$$PATH$$/3388.dat';

--
-- Data for Name: sales; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.sales (user_id, product_id, sell_price, total_sale_amount, quantity_sold, sale_time, transaction_id) FROM stdin;
\.
COPY public.sales (user_id, product_id, sell_price, total_sale_amount, quantity_sold, sale_time, transaction_id) FROM '$$PATH$$/3389.dat';

--
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.transactions (transaction_id, purchase_price, payment_method, sale_time, user_id) FROM stdin;
\.
COPY public.transactions (transaction_id, purchase_price, payment_method, sale_time, user_id) FROM '$$PATH$$/3390.dat';

--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public."user" (user_id, name, is_seller, is_admin, phone_number, address, cart_id, email_address, password_hash) FROM stdin;
\.
COPY public."user" (user_id, name, is_seller, is_admin, phone_number, address, cart_id, email_address, password_hash) FROM '$$PATH$$/3391.dat';

--
-- Name: __drizzle_migrations_id_seq; Type: SEQUENCE SET; Schema: drizzle; Owner: root
--

SELECT pg_catalog.setval('drizzle.__drizzle_migrations_id_seq', 1, true);


--
-- Name: __drizzle_migrations __drizzle_migrations_pkey; Type: CONSTRAINT; Schema: drizzle; Owner: root
--

ALTER TABLE ONLY drizzle.__drizzle_migrations
    ADD CONSTRAINT __drizzle_migrations_pkey PRIMARY KEY (id);


--
-- Name: carts carts_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.carts
    ADD CONSTRAINT carts_pkey PRIMARY KEY (cart_sno);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (product_id);


--
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (transaction_id);


--
-- Name: user user_cart_id_unique; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_cart_id_unique UNIQUE (cart_id);


--
-- Name: user user_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (user_id);


--
-- Name: carts carts_product_id_products_product_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.carts
    ADD CONSTRAINT carts_product_id_products_product_id_fk FOREIGN KEY (product_id) REFERENCES public.products(product_id);


--
-- Name: carts carts_user_id_user_user_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.carts
    ADD CONSTRAINT carts_user_id_user_user_id_fk FOREIGN KEY (user_id) REFERENCES public."user"(user_id);


--
-- Name: products products_seller_id_user_user_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_seller_id_user_user_id_fk FOREIGN KEY (seller_id) REFERENCES public."user"(user_id);


--
-- Name: sales sales_product_id_products_product_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_product_id_products_product_id_fk FOREIGN KEY (product_id) REFERENCES public.products(product_id);


--
-- Name: sales sales_transaction_id_transactions_transaction_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_transaction_id_transactions_transaction_id_fk FOREIGN KEY (transaction_id) REFERENCES public.transactions(transaction_id);


--
-- Name: sales sales_user_id_user_user_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_user_id_user_user_id_fk FOREIGN KEY (user_id) REFERENCES public."user"(user_id);


--
-- Name: transactions transactions_user_id_user_user_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_user_id_user_user_id_fk FOREIGN KEY (user_id) REFERENCES public."user"(user_id);


--
-- PostgreSQL database dump complete
--

